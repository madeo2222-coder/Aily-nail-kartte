import {Buffer} from 'buffer';
import * as crypto from 'crypto';

export class AuthHashUtil {

    public static checkAuthHash(body: any, merchantCcId: string, merchantPw: string): boolean {

        if (!body.hasOwnProperty("authParams") || !body["authParams"]) {
            return false;
        }
        const authParams = body["authParams"];

        if (!body.hasOwnProperty("vAuthInfo") || !body["vAuthInfo"]) {
            return false;
        }
        const vAuthInfo = body["vAuthInfo"];

        const hash = this.createAuthHashInfo(body, authParams, merchantCcId, merchantPw);
        return vAuthInfo == hash;
    }

    private static createAuthHashInfo(body: any, authParams: string, merchantCcId: string, merchantPw: string): string {

        const buffer = Buffer.from(authParams, 'base64');
        const decoded = buffer.toString();
        const params = decoded.split(",");

        let str = merchantCcId;
        params.forEach(value => {
            if (body.hasOwnProperty(value)) {
                str += body[value];
            }
        });
        str += merchantPw;

        const sha256 = crypto.createHash('sha256');
        sha256.update(str);
        return sha256.digest('hex');
    }


}
