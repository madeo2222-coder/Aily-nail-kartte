import {Response} from "node-fetch"

export interface IHttpClient {

    execute(uri: string, json: string): Promise<Response>;

}