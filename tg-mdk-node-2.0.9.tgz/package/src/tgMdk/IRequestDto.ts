export interface IRequestDto {

    readonly serviceType: string;
    readonly serviceCommand: string;
    maskedLog: string | undefined;

    txnVersion?: string | undefined;
    dummyRequest?: string | undefined;
    merchantCcid?: string | undefined;

}
