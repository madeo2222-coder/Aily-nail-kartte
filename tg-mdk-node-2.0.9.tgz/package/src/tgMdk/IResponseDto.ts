export interface IResponseDto {

    resultJson: string | undefined;

    mstatus?: string | undefined;

    vResultCode?: string | undefined;

    merrMsg?: string | undefined;

}
