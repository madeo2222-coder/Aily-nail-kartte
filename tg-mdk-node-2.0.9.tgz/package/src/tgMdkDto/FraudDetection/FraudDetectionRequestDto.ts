import {FraudDetectionOrderDto} from "./FraudDetectionOrderDto.js";
import {FraudDetectionTransactionDto} from "./FraudDetectionTransactionDto.js";
import {FraudDetectionTotalDto} from "./FraudDetectionTotalDto.js";
import {FraudDetectionSessionDto} from "./FraudDetectionSessionDto.js";
import {FraudDetectionUserAccountDto} from "./FraudDetectionUserAccountDto.js";
import {FraudDetectionContactDto} from "./FraudDetectionContactDto.js";
import {FraudDetectionExternalRiskResultDto} from "./FraudDetectionExternalRiskResultDto.js";
import {FraudDetectionDeviceDto} from "./FraudDetectionDeviceDto.js";


export class FraudDetectionRequestDto {

    constructor(device: FraudDetectionDeviceDto) {
        this.device = device;
    }


    orgCode: string | undefined;


    modelCode: string | undefined;


    merchantId: string | undefined;


    bruceSector: string | undefined;


    customField1: string | undefined;


    customField2: string | undefined;


    customField3: string | undefined;


    ebtUserData1: string | undefined;


    ebtUserData2: string | undefined;


    ebtUserData3: string | undefined;


    ebtUserData4: string | undefined;


    ebtUserData5: string | undefined;


    ebtUserData6: string | undefined;


    ebtUserData7: string | undefined;


    ebtUserData8: string | undefined;


    ebtUserData9: string | undefined;


    ebtUserData10: string | undefined;


    ebtUserData11: string | undefined;


    ebtUserData12: string | undefined;


    ebtUserData13: string | undefined;


    ebtUserData14: string | undefined;


    ebtUserData15: string | undefined;


    ebtUserData16: string | undefined;


    ebtUserData17: string | undefined;


    ebtUserData18: string | undefined;


    ebtUserData19: string | undefined;


    ebtUserData20: string | undefined;


    ebtUserData21: string | undefined;


    ebtUserData22: string | undefined;


    ebtUserData23: string | undefined;


    ebtUserData24: string | undefined;


    ebtUserData25: string | undefined;


    actCd: string | undefined;


    divNum: string | undefined;


    SKeyId: string | undefined;


    ebtService: string | undefined;


    ebtName: string | undefined;


    userId: string | undefined;


    id: string | undefined;


    time: string | undefined;


    source: string | undefined;


    device: FraudDetectionDeviceDto;


    externalRiskResults: FraudDetectionExternalRiskResultDto[] | undefined;


    contacts: FraudDetectionContactDto[] | undefined;


    userAccount: FraudDetectionUserAccountDto | undefined;


    session: FraudDetectionSessionDto | undefined;


    total: FraudDetectionTotalDto | undefined;


    transaction: FraudDetectionTransactionDto | undefined;


    order: FraudDetectionOrderDto | undefined;

}
