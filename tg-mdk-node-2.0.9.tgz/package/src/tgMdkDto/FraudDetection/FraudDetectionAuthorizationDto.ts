export class FraudDetectionAuthorizationDto {


    declined: string | undefined;


    approvalCode: string | undefined;


    avsAddr: string | undefined;


    avsZip: string | undefined;


    cvv2: string | undefined;


    ddds: string | undefined;


    eci: string | undefined;


    xid: string | undefined;


    bank: string | undefined;


    type: string | undefined;


    enhAuthPhone: string | undefined;


    enhAuthName: string | undefined;


    enhAuthEmail: string | undefined;


    psAddr: string | undefined;


    psPayer: string | undefined;

}
