import {FraudDetectionAuthorizationDto} from "./FraudDetectionAuthorizationDto.js";


export class FraudDetectionMethodCardDto {


    type: string | undefined;


    brand: string | undefined;


    cardHolderName: string | undefined;


    cardBin: string | undefined;


    cardLastFour: string | undefined;


    hashedCardNumber: string | undefined;


    expireDate: string | undefined;


    tof: string | undefined;


    authorization: FraudDetectionAuthorizationDto | undefined;

}
