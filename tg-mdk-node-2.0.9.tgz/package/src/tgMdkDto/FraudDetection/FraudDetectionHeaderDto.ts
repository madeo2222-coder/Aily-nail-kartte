export class FraudDetectionHeaderDto {

    constructor(headerName: string, headerValue: string) {
        this.headerName = headerName;
        this.headerValue = headerValue;
    }


    headerName: string;


    headerValue: string;

}
