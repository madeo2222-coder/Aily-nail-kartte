export class FraudDetectionUserIdentityCookieDto {

    constructor(cookieName: string, cookieValue: string) {
        this.cookieName = cookieName;
        this.cookieValue = cookieValue;
    }


    cookieName: string;


    cookieValue: string;

}
