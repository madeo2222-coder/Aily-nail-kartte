import {FraudDetectionLastActionTimesDto} from "./FraudDetectionLastActionTimesDto.js";


export class FraudDetectionUserAccountDto {


    id: string | undefined;


    enrollmentTime: string | undefined;


    accountHolder: string | undefined;


    returnCustomer: string | undefined;


    username: string | undefined;


    tof: string | undefined;


    lastActionTimes: FraudDetectionLastActionTimesDto | undefined;

}
