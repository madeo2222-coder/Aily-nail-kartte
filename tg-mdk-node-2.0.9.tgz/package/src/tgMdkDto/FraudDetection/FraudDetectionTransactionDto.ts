import {FraudDetectionCashValueDto} from "./FraudDetectionCashValueDto.js";
import {FraudDetectionMethodCardDto} from "./FraudDetectionMethodCardDto.js";


export class FraudDetectionTransactionDto {


    type: string | undefined;


    id: string | undefined;


    cashValue: FraudDetectionCashValueDto | undefined;


    comment: string | undefined;


    time: string | undefined;


    payer: string | undefined;


    category: string | undefined;


    methodCard: FraudDetectionMethodCardDto | undefined;

}
