export class FraudDetectionLineItemDto {

    constructor(refId: string) {
        this.refId = refId;
    }


    refId: string;


    name: string | undefined;


    description: string | undefined;


    sku: string | undefined;


    eanCode: string | undefined;


    promoCode: string | undefined;


    category: string | undefined;


    brand: string | undefined;


    sellerId: string | undefined;


    unitWeight: string | undefined;


    unit: string | undefined;


    quantity: string | undefined;


    unitAmount: string | undefined;


    unitCurrencyCode: string | undefined;


    totalAmount: string | undefined;


    totalCurrencyCode: string | undefined;

}
