export class FraudDetectionAgResponseDto {


    decision: string | undefined;


    hitRules: string[] | undefined;


    hitReasons: string[] | undefined;


    errors: string[] | undefined;


    message: string | undefined;

}
