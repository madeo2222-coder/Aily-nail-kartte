import {FraudDetectionHeaderDto} from "./FraudDetectionHeaderDto.js";
import {FraudDetectionUserIdentityCookieDto} from "./FraudDetectionUserIdentityCookieDto.js";


export class FraudDetectionDeviceDto {

    constructor(ip: string, headers: FraudDetectionHeaderDto[]) {
        this.ip = ip;
        this.headers = headers;
    }


    ip: string;


    headers: FraudDetectionHeaderDto[];


    userIdentityCookies: FraudDetectionUserIdentityCookieDto[] | undefined;


    devicePrint: string | undefined;

}
