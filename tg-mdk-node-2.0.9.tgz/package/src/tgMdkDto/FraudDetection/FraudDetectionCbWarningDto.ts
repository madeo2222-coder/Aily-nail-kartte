export class FraudDetectionCbWarningDto {


    path: string | undefined;


    message: string | undefined;


    value: string | undefined;

}
