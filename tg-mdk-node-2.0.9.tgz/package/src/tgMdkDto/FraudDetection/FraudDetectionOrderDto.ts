import {FraudDetectionLineItemDto} from "./FraudDetectionLineItemDto.js";
import {FraudDetectionShipmentDto} from "./FraudDetectionShipmentDto.js";


export class FraudDetectionOrderDto {


    id: string | undefined;


    source: string | undefined;


    promoCode: string | undefined;


    failedPaymentAttempts: string | undefined;


    oiRepeat: string | undefined;


    lineItems: FraudDetectionLineItemDto[] | undefined;


    shipment: FraudDetectionShipmentDto | undefined;

}
