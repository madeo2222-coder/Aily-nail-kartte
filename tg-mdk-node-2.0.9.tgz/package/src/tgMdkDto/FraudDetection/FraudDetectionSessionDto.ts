export class FraudDetectionSessionDto {

    constructor(id: string) {
        this.id = id;
    }


    id: string;


    itemsRemoved: string | undefined;


    durationInMillis: string | undefined;


    activityPageCode: string | undefined;


    failedLoginAttempts: string | undefined;


    thirdPartySessionId: string | undefined;


    loggedIn: string | undefined;


    multiFactorAuthenticated: string | undefined;


    challengeAttempts: string | undefined;

}
