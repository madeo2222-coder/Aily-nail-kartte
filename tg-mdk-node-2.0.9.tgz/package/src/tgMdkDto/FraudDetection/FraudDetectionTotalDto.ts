export class FraudDetectionTotalDto {


    amount: string | undefined;


    currencyCode: string | undefined;

}
