import {FraudDetectionCbResponseDto} from "./FraudDetectionCbResponseDto.js";
import {FraudDetectionRdResponseDto} from "./FraudDetectionRdResponseDto.js";
import {FraudDetectionAgResponseDto} from "./FraudDetectionAgResponseDto.js";


export class FraudDetectionResponseDto {


    result: string | undefined;


    service: string | undefined;


    cbResponse: FraudDetectionCbResponseDto | undefined;


    rdResponse: FraudDetectionRdResponseDto | undefined;


    agResponse: FraudDetectionAgResponseDto | undefined;

}
