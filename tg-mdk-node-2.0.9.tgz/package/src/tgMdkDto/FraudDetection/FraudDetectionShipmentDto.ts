import {FraudDetectionCostDto} from "./FraudDetectionCostDto.js";


export class FraudDetectionShipmentDto {


    recipient: string | undefined;


    shipTypeCd: string | undefined;


    scheduledShipTime: string | undefined;


    insured: string | undefined;


    method: string | undefined;


    comment: string | undefined;


    trackingNumber: string | undefined;


    cost: FraudDetectionCostDto | undefined;


    lineItems: string[] | undefined;

}
