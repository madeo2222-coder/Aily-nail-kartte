export class FraudDetectionExternalRiskResultDto {


    source: string | undefined;


    score: string | undefined;


    code: string | undefined;

}
