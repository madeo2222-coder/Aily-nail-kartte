export class FraudDetectionCostDto {

    constructor(amount: string) {
        this.amount = amount;
    }


    amount: string;


    currencyCode: string | undefined;

}
