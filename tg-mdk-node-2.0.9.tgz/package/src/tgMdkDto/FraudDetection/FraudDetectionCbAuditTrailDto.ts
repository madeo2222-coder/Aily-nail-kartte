export class FraudDetectionCbAuditTrailDto {


    code: string | undefined;


    ruleScore: string | undefined;


    ruleAction: string | undefined;

}
