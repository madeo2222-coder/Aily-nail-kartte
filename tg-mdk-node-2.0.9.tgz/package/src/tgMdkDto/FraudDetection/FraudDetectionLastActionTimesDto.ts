export class FraudDetectionLastActionTimesDto {


    previousSuccessfulLogin: string | undefined;


    transferThresholdUpdated: string | undefined;

}
