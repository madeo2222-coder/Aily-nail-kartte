export class FraudDetectionRdResponseDto {


    code: string | undefined;


    requestId: string | undefined;


    orderId: string | undefined;


    riskStatusCode: string | undefined;


    riskFraudStatusCode: string | undefined;


    riskResponseCode: string | undefined;


    riskOrderId: string | undefined;


    riskNeuralScore: string | undefined;


    riskRuleCategory: string | undefined;


    id: string | undefined;


    description: string | undefined;


    merchantTransactionId: string | undefined;


    buildNumber: string | undefined;


    timestamp: string | undefined;


    ndc: string | undefined;


    resultDescription: string | undefined;


    externalSystemLink: string | undefined;


    action: string | undefined;


    riskReport: string | undefined;


    riskFraudDescription: string | undefined;


    transactionId: string | undefined;


    parameterErrors: string | undefined;


    targetServiceTypeCd: string | undefined;


    targetOrderId: string | undefined;

}
