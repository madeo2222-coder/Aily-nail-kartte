import {FraudDetectionCbWarningDto} from "./FraudDetectionCbWarningDto.js";
import {FraudDetectionCbAuditTrailDto} from "./FraudDetectionCbAuditTrailDto.js";


export class FraudDetectionCbResponseDto {


    id: string | undefined;


    modelCode: string | undefined;


    modelVersion: string | undefined;


    orgCode: string | undefined;


    time: string | undefined;


    score: string | undefined;


    deviceId: string | undefined;


    tdl: string | undefined;


    systemResponse: string | undefined;


    fulfillmentAction: string | undefined;


    auditTrail: FraudDetectionCbAuditTrailDto[] | undefined;


    riskLevel: string | undefined;


    warnings: FraudDetectionCbWarningDto[] | undefined;

}
