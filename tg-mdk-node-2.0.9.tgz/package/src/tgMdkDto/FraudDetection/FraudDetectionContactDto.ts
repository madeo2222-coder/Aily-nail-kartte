export class FraudDetectionContactDto {

    constructor(refId: string, firstName: string, lastName: string, countryCode: string) {
        this.refId = refId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.countryCode = countryCode;
    }


    refId: string;


    firstName: string;


    lastName: string;


    company: string | undefined;


    emailAddress: string | undefined;


    emailAddressType: string | undefined;


    phoneNumber: string | undefined;


    phoneNumberType: string | undefined;


    streetLine: string | undefined;


    streetLine2: string | undefined;


    city: string | undefined;


    postal: string | undefined;


    stateProvinceCode: string | undefined;


    countryCode: string;


    birthDate: string | undefined;


    mothersMaidenName: string | undefined;

}
