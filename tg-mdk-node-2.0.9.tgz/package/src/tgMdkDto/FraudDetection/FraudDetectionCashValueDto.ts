export class FraudDetectionCashValueDto {


    amount: string | undefined;


    currencyCode: string | undefined;

}
