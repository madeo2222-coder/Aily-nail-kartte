import {AbstractPaymentCreditRequestDto} from "../Card/AbstractPaymentCreditRequestDto.js";
import type {IRequestDto} from "../../tgMdk/IRequestDto.js";


export class MpiGetResultRequestDto extends AbstractPaymentCreditRequestDto implements IRequestDto {
    readonly serviceType: string = "mpi";
    readonly serviceCommand: string = "GetResult";


    orderId: string | undefined;

    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }

}
