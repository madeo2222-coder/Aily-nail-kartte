import {AbstractPaymentCreditRequestDto} from "../Card/AbstractPaymentCreditRequestDto.js";
import {OptionParam} from "../OptionParam.js";
import {FraudDetectionRequestDto} from "../FraudDetection/FraudDetectionRequestDto.js";
import type {IRequestDto} from "../../tgMdk/IRequestDto.js";
import {FraudDetectionV2RequestDto} from "../FraudDetectionV2/FraudDetectionV2RequestDto.js";


export class MpiAuthorizeRequestDto extends AbstractPaymentCreditRequestDto implements IRequestDto {
    readonly serviceType: string = "mpi";
    readonly serviceCommand: string = "Authorize";


    serviceOptionType: string | undefined;


    orderId: string | undefined;


    amount: string | undefined;


    cardNumber: string | undefined;


    cardExpire: string | undefined;


    cardCenter: string | undefined;


    acquirerCode: string | undefined;


    jpo: string | undefined;


    withCapture: string | undefined;


    salesDay: string | undefined;


    itemCode: string | undefined;


    securityCode: string | undefined;


    birthday: string | undefined;


    tel: string | undefined;


    firstKanaName: string | undefined;


    lastKanaName: string | undefined;


    currencyUnit: string | undefined;


    redirectionUri: string | undefined;


    httpUserAgent: string | undefined;


    httpAccept: string | undefined;


    firstPayment: string | undefined;


    bonusFirstPayment: string | undefined;


    mcAmount: string | undefined;


    pushUrl: string | undefined;


    browserDeviceCategory: string | undefined;


    verifyResultLink: string | undefined;


    tempRegistration: string | undefined;


    verifyTimeout: string | undefined;


    fraudDetectionRequest: FraudDetectionRequestDto | undefined;


    fraudDetectionV2Request: FraudDetectionV2RequestDto | undefined;


    withFraudDetection: string | undefined;


    deviceChannel: string | undefined;


    accountType: string | undefined;


    authenticationIndicator: string | undefined;


    messageCategory: string | undefined;


    cardholderName: string | undefined;


    cardholderNameOmitFlag: string | undefined;


    cardholderEmail: string | undefined;


    cardholderHomePhoneCountry: string | undefined;


    cardholderHomePhoneNumber: string | undefined;


    cardholderMobilePhoneCountry: string | undefined;


    cardholderMobilePhoneNumber: string | undefined;


    cardholderWorkPhoneCountry: string | undefined;


    cardholderWorkPhoneNumber: string | undefined;


    billingAddressCity: string | undefined;


    billingAddressCountry: string | undefined;


    billingAddressLine1: string | undefined;


    billingAddressLine2: string | undefined;


    billingAddressLine3: string | undefined;


    billingPostalCode: string | undefined;


    billingAddressState: string | undefined;


    shippingAddressCity: string | undefined;


    shippingAddressCountry: string | undefined;


    shippingAddressLine1: string | undefined;


    shippingAddressLine2: string | undefined;


    shippingAddressLine3: string | undefined;


    shippingPostalCode: string | undefined;


    shippingAddressState: string | undefined;


    customerIp: string | undefined;


    withChallenge: string | undefined;


    authData: string | undefined;


    authMethod: string | undefined;


    authTimestamp: string | undefined;


    accountAgeIndicator: string | undefined;


    accountChangeDate: string | undefined;


    accountChangeIndicator: string | undefined;


    accountDate: string | undefined;


    accountPasswordChangeDate: string | undefined;


    accountPasswordChangeIndicator: string | undefined;


    accountPurchaseCount: string | undefined;


    accountProvisioningAttempts: string | undefined;


    accountDayTransactions: string | undefined;


    accountYearTransactions: string | undefined;


    paymentAccountAge: string | undefined;


    paymentAccountAgeIndicator: string | undefined;


    shipAddressUsageDate: string | undefined;


    shipAddressUsageIndicator: string | undefined;


    shipNameIndicator: string | undefined;


    suspiciousAccountActivity: string | undefined;


    requestorChallengeIndicator: string | undefined;


    deliveryEmailAddress: string | undefined;


    preOrderPurchaseIndicator: string | undefined;


    reorderItemsIndicator: string | undefined;


    shipIndicator: string | undefined;


    mpiAcquirerCode: string | undefined;


    exSlipInfo: string | undefined;


    addressMatchIndicator: string | undefined;


    optionParams: OptionParam[] | undefined;

    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }

}
