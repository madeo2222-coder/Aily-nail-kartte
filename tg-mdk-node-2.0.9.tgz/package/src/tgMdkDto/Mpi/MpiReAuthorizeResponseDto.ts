import {MdkDtoBase} from "../MdkDtoBase.js";
import {PayNowIdResponse} from "../PayNowId/PayNowIdResponse.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class MpiReAuthorizeResponseDto extends MdkDtoBase implements IResponseDto {

    private _resultJson: string | undefined;


    serviceType: string | undefined;


    mstatus: string | undefined;


    vResultCode: string | undefined;


    merrMsg: string | undefined;


    marchTxn: string | undefined;


    orderId: string | undefined;


    custTxn: string | undefined;


    txnVersion: string | undefined;


    mpiTransactiontype: string | undefined;


    reqCardNumber: string | undefined;


    reqCardExpire: string | undefined;


    reqAmount: string | undefined;


    reqAcquirerCode: string | undefined;


    reqItemCode: string | undefined;


    reqCardCenter: string | undefined;


    reqJpoInformation: string | undefined;


    reqSalesDay: string | undefined;


    reqWithCapture: string | undefined;


    reqSecurityCode: string | undefined;


    reqBirthday: string | undefined;


    reqTel: string | undefined;


    reqFirstKanaName: string | undefined;


    reqLastKanaName: string | undefined;


    reqCurrencyUnit: string | undefined;


    reqRedirectionUri: string | undefined;


    reqHttpUserAgent: string | undefined;


    reqHttpAccept: string | undefined;


    resResponseContents: string | undefined;


    resCorporationId: string | undefined;


    resBrandId: string | undefined;


    res3dMessageVersion: string | undefined;


    authRequestDatetime: string | undefined;


    authResponseDatetime: string | undefined;


    kindCode: string | undefined;


    authStartUrl: string | undefined;


    payNowIdResponse: PayNowIdResponse | undefined;

    get resultJson(): string | undefined {
        return this._resultJson;
    }

    set resultJson(value: string) {
        this._resultJson = value;
    }

}
