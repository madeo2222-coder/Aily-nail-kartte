import {MdkDtoBase} from "../MdkDtoBase.js";
import {PayNowIdResponse} from "../PayNowId/PayNowIdResponse.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class MpiGetResultResponseDto extends MdkDtoBase implements IResponseDto {

    private _resultJson: string | undefined;


    serviceType: string | undefined;


    mstatus: string | undefined;


    vResultCode: string | undefined;


    merrMsg: string | undefined;


    orderId: string | undefined;


    txnVersion: string | undefined;


    requestId: string | undefined;


    reqAmount: string | undefined;


    reqCardNumber: string | undefined;


    reqCurrencyUnit: string | undefined;


    mpiMstatus: string | undefined;


    mpiVresultCode: string | undefined;


    txnType: string | undefined;


    cardMstatus: string | undefined;


    cardTransactionType: string | undefined;


    centerRequestDate: string | undefined;


    centerResponseDate: string | undefined;


    connectedCenterId: string | undefined;


    acquirerCode: string | undefined;


    authCode: string | undefined;


    fdResult: string | undefined;


    dddMessageVersion: string | undefined;


    dddTransactionId: string | undefined;


    dddDsTransactionId: string | undefined;


    dddServerTransactionId: string | undefined;


    dddTransactionStatus: string | undefined;


    dddTransactionStatusReason: string | undefined;


    dddCavvAlgorithm: string | undefined;


    dddCavv: string | undefined;


    dddEci: string | undefined;


    payNowIdResponse: PayNowIdResponse | undefined;

    get resultJson(): string | undefined {
        return this._resultJson;
    }

    set resultJson(value: string) {
        this._resultJson = value;
    }

}
