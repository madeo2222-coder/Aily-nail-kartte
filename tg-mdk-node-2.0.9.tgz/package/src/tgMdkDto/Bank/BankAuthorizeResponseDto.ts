import {MdkDtoBase} from "../MdkDtoBase.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class BankAuthorizeResponseDto extends MdkDtoBase implements IResponseDto {

    private _resultJson: string | undefined;


    serviceType: string | undefined;


    mstatus: string | undefined;


    vResultCode: string | undefined;


    merrMsg: string | undefined;


    marchTxn: string | undefined;


    orderId: string | undefined;


    custTxn: string | undefined;


    requestId: string | undefined;


    shunoKikanNo: string | undefined;


    customerNo: string | undefined;


    confirmNo: string | undefined;


    billPattern: string | undefined;


    bill: string | undefined;


    url: string | undefined;


    view: string | undefined;


    txnVersion: string | undefined;

    get resultJson(): string | undefined {
        return this._resultJson;
    }

    set resultJson(value: string) {
        this._resultJson = value;
    }

}
