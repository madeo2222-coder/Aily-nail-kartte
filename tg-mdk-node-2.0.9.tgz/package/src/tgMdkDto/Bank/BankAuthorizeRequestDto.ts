import type {IRequestDto} from "../../tgMdk/IRequestDto.js";
import {AbstractPaymentRequestDto} from "../AbstractPaymentRequestDto.js";


export class BankAuthorizeRequestDto extends AbstractPaymentRequestDto implements IRequestDto {
    readonly serviceType: string = "bank";
    readonly serviceCommand: string = "Authorize";


    serviceOptionType: string | undefined;


    orderId: string | undefined;


    amount: string | undefined;


    name1: string | undefined;


    name2: string | undefined;


    kana1: string | undefined;


    kana2: string | undefined;


    post1: string | undefined;


    post2: string | undefined;


    address1: string | undefined;


    address2: string | undefined;


    address3: string | undefined;


    telNo: string | undefined;


    payLimit: string | undefined;


    agreementDate: string | undefined;


    contents: string | undefined;


    contentsKana: string | undefined;


    payCsv: string | undefined;


    viewLocale: string | undefined;


    termUrl: string | undefined;


    pushUrl: string | undefined;


    pushExpantionFlag: string | undefined;


    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }

}
