import {MdkDtoBase} from "../MdkDtoBase.js";
import {PayNowIdResponse} from "../PayNowId/PayNowIdResponse.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";
import {FraudDetectionResponseDto} from "../FraudDetection/FraudDetectionResponseDto.js";


export class CardNoAuthorizeFraudDetectionResponseDto extends MdkDtoBase implements IResponseDto {

    private _resultJson: string | undefined;


    serviceType: string | undefined;


    mstatus: string | undefined;


    vResultCode: string | undefined;


    merrMsg: string | undefined;


    marchTxn: string | undefined;


    orderId: string | undefined;


    custTxn: string | undefined;


    txnVersion: string | undefined;


    cardTransactiontype: string | undefined;


    gatewayRequestDate: string | undefined;


    gatewayResponseDate: string | undefined;


    centerRequestDate: string | undefined;


    centerResponseDate: string | undefined;


    pending: string | undefined;


    loopback: string | undefined;


    connectedCenterId: string | undefined;


    centerRequestNumber: string | undefined;


    centerReferenceNumber: string | undefined;


    reqCardNumber: string | undefined;


    reqCardExpire: string | undefined;


    reqCardOptionType: string | undefined;


    reqAmount: string | undefined;


    reqMerchantTransaction: string | undefined;


    reqReturnReferenceNumber: string | undefined;


    reqAuthCode: string | undefined;


    reqAcquirerCode: string | undefined;


    reqItemCode: string | undefined;


    reqCardCenter: string | undefined;


    reqJpoInformation: string | undefined;


    reqSalesDay: string | undefined;


    reqCancelDay: string | undefined;


    reqWithCapture: string | undefined;


    reqWithDirect: string | undefined;


    req3dMessageVersion: string | undefined;


    req3dTransactionId: string | undefined;


    req3dTransactionStatus: string | undefined;


    req3dCavvAlgorithm: string | undefined;


    req3dCavv: string | undefined;


    req3dEci: string | undefined;


    reqSecurityCode: string | undefined;


    reqAuthFlag: string | undefined;


    reqBirthday: string | undefined;


    reqTel: string | undefined;


    reqFirstKanaName: string | undefined;


    reqLastKanaName: string | undefined;


    resMerchantTransaction: string | undefined;


    resReturnReferenceNumber: string | undefined;


    resAuthCode: string | undefined;


    resActionCode: string | undefined;


    resCenterErrorCode: string | undefined;


    resAuthTerm: string | undefined;


    resItemCode: string | undefined;


    resResponseData: string | undefined;


    reqCurrencyUnit: string | undefined;


    reqWithNew: string | undefined;


    acquirerCode: string | undefined;


    terminalId: string | undefined;


    fraudDetectionResponse: FraudDetectionResponseDto | undefined;


    resCenterProcessNumber: string | undefined;


    resCenterSendDateTime: string | undefined;


    resGiftBalance: string | undefined;


    resGiftExpire: string | undefined;


    kindCode: string | undefined;


    jcnTokenResultCode: string | undefined;


    jcnTokenMemberNum: string | undefined;


    jcnTokenVersion: string | undefined;


    jcnTokenResult1: string | undefined;


    jcnTokenResult2: string | undefined;


    jcnTokenResCode: string | undefined;


    payNowIdResponse: PayNowIdResponse | undefined;

    get resultJson(): string | undefined {
        return this._resultJson;
    }

    set resultJson(value: string) {
        this._resultJson = value;
    }

}
