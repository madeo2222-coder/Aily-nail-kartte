import {AbstractPaymentCreditRequestDto} from "./AbstractPaymentCreditRequestDto.js";
import {FraudDetectionRequestDto} from "../FraudDetection/FraudDetectionRequestDto.js";
import type {IRequestDto} from "../../tgMdk/IRequestDto.js";
import {FraudDetectionV2RequestDto} from "../FraudDetectionV2/FraudDetectionV2RequestDto.js";


export class CardReAuthorizeRequestDto extends AbstractPaymentCreditRequestDto implements IRequestDto {
    readonly serviceType: string = "card";
    readonly serviceCommand: string = "ReAuthorize";


    orderId: string | undefined;


    originalOrderId: string | undefined;


    amount: string | undefined;


    cardNumber: string | undefined;


    cardExpire: string | undefined;


    cardOptionType: string | undefined;


    cardCenter: string | undefined;


    acquirerCode: string | undefined;


    jpo: string | undefined;


    withCapture: string | undefined;


    salesDay: string | undefined;


    itemCode: string | undefined;


    dddMessageVersion: string | undefined;


    dddTransactionId: string | undefined;


    dddTransactionStatus: string | undefined;


    dddCavvAlgorithm: string | undefined;


    dddCavv: string | undefined;


    dddEci: string | undefined;


    dddDsTransactionId: string | undefined;


    dddServerTransactionId: string | undefined;


    securityCode: string | undefined;


    authFlag: string | undefined;


    birthday: string | undefined;


    tel: string | undefined;


    firstKanaName: string | undefined;


    lastKanaName: string | undefined;


    currencyUnit: string | undefined;

    pin: string | undefined;


    firstPayment: string | undefined;


    bonusFirstPayment: string | undefined;


    mcAmount: string | undefined;


    posDataCode: string | undefined;


    terminalId: string | undefined;


    fraudDetectionRequest: FraudDetectionRequestDto | undefined;


    fraudDetectionV2Request: FraudDetectionV2RequestDto | undefined;


    withFraudDetection: string | undefined;


    exSlipInfo: string | undefined;

    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }

}
