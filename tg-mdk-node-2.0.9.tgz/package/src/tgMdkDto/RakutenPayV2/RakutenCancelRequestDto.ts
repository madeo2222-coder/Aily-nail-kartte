import type {IRequestDto} from "../../tgMdk/IRequestDto.js";
import {AbstractPaymentRequestDto} from "../AbstractPaymentRequestDto.js";


export class RakutenCancelRequestDto extends AbstractPaymentRequestDto implements IRequestDto {
    readonly serviceType: string = "rakuten";
    readonly serviceCommand: string = "Cancel";


    orderId: string | undefined;


    amount: string | undefined;


    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }

}

