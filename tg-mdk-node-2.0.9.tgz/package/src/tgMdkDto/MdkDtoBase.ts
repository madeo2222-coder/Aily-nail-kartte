export class MdkDtoBase {

}
