import {FraudDetectionV2BrowserFingerprintDto} from "./FraudDetectionV2BrowserFingerprintDto.js";


export class FraudDetectionV2CustomerDto {


    merchantCustomerId: string | undefined;


    givenName: string | undefined;


    middleName: string | undefined;


    surname: string | undefined;


    sex: string | undefined;


    workPhone: string | undefined;


    birthDate: string | undefined;


    phone: string | undefined;


    mobile: string | undefined;


    email: string | undefined;


    companyName: string | undefined;


    ip: string | undefined;


    browserFingerprint: FraudDetectionV2BrowserFingerprintDto | undefined;


    identificationDocId: string | undefined;


    status: string | undefined;

}
