import {FraudDetectionV2PassengerDto} from "./FraudDetectionV2PassengerDto.js";


export class FraudDetectionV2AirlineDto {


    thirdPartyBooking: string | undefined;


    agentCode: string | undefined;


    agentName: string | undefined;


    bookingType: string | undefined;


    bookingRefNum: string | undefined;


    ticketDeliveryMethod: string | undefined;


    ticketIssueAddress: string | undefined;


    ticketIssueDate: string | undefined;


    totalTaxAmount: string | undefined;


    totalFareAmount: string | undefined;


    totalFeesAmount: string | undefined;


    passengers: FraudDetectionV2PassengerDto[] | undefined;

}
