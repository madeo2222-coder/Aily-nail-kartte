import {FraudDetectionV2CustomerDto} from "./FraudDetectionV2CustomerDto.js";


export class FraudDetectionV2ShippingDto {


    customer: FraudDetectionV2CustomerDto | undefined;


    houseNumber1: string | undefined;


    street1: string | undefined;


    street2: string | undefined;


    city: string | undefined;


    state: string | undefined;


    country: string | undefined;


    postcode: string | undefined;


    cost: string | undefined;


    trackingNumber: string | undefined;


    comment: string | undefined;


    logisticsProvider: string | undefined;


    method: string | undefined;

}
