export class FraudDetectionV2BrowserFingerprintDto {


    value: string | undefined;

}
