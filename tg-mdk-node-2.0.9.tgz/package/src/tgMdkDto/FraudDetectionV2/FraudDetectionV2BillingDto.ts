export class FraudDetectionV2BillingDto {


    houseNumber1: string | undefined;


    street1: string | undefined;


    street2: string | undefined;


    city: string | undefined;


    state: string | undefined;


    country: string | undefined;


    postcode: string | undefined;

}
