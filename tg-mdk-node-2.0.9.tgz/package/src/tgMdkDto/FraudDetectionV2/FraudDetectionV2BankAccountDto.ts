export class FraudDetectionV2BankAccountDto {


    holder: string | undefined;

}
