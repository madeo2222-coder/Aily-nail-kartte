export class FraudDetectionV2ParametersDto {


    timeOnFile: string | undefined;


    custVerification: string | undefined;


    authResponse: string | undefined;


    avsResponse: string | undefined;


    cvvIndicator: string | undefined;


    cvvResponse: string | undefined;


    cavvStatus: string | undefined;


    parentOid: string | undefined;


    rtrLeg: string | undefined;


    itemProdCategory: string[] | undefined;


    userData1: string | undefined;


    userData2: string | undefined;


    userData3: string | undefined;


    userData4: string | undefined;


    userData5: string | undefined;


    userData6: string | undefined;


    userData7: string | undefined;


    userData8: string | undefined;


    userData9: string | undefined;


    userData10: string | undefined;


    userData11: string | undefined;


    userData12: string | undefined;


    userData13: string | undefined;


    userData14: string | undefined;


    userData15: string | undefined;


    userData16: string | undefined;


    userData17: string | undefined;


    userData18: string | undefined;


    userData19: string | undefined;


    userData20: string | undefined;


    userData21: string | undefined;


    userData22: string | undefined;


    userData23: string | undefined;


    userData24: string | undefined;


    userData25: string | undefined;


    userData26: string | undefined;


    userData27: string | undefined;


    userData28: string | undefined;


    userData29: string | undefined;


    userData30: string | undefined;


    userData31: string | undefined;


    userData32: string | undefined;


    userData33: string | undefined;


    userData34: string | undefined;


    userData35: string | undefined;


    userData36: string | undefined;


    userData37: string | undefined;


    userData38: string | undefined;


    userData39: string | undefined;


    userData40: string | undefined;


    userData41: string | undefined;


    userData42: string | undefined;


    userData43: string | undefined;


    userData44: string | undefined;


    userData45: string | undefined;


    userData46: string | undefined;


    userData47: string | undefined;


    userData48: string | undefined;


    userData49: string | undefined;


    userData50: string | undefined;


    userData51: string | undefined;


    userData52: string | undefined;


    userData53: string | undefined;


    userData54: string | undefined;


    userData55: string | undefined;


    userData56: string | undefined;


    userData57: string | undefined;


    userData58: string | undefined;


    userData59: string | undefined;


    userData60: string | undefined;


    userData61: string | undefined;


    userData62: string | undefined;


    userData63: string | undefined;


    userData64: string | undefined;


    userData65: string | undefined;


    userData66: string | undefined;


    userData67: string | undefined;


    userData68: string | undefined;


    userData69: string | undefined;


    userData70: string | undefined;


    userData71: string | undefined;


    userData72: string | undefined;


    userData73: string | undefined;


    userData74: string | undefined;


    userData75: string | undefined;


    userData76: string | undefined;


    userData77: string | undefined;


    userData78: string | undefined;


    userData79: string | undefined;


    userData80: string | undefined;


    userData81: string | undefined;


    userData82: string | undefined;


    userData83: string | undefined;


    userData84: string | undefined;


    userData85: string | undefined;


    userData86: string | undefined;


    userData87: string | undefined;


    userData88: string | undefined;


    userData89: string | undefined;


    userData90: string | undefined;


    userData91: string | undefined;


    userData92: string | undefined;


    userData93: string | undefined;


    userData94: string | undefined;


    userData95: string | undefined;


    userData96: string | undefined;


    userData97: string | undefined;


    userData98: string | undefined;


    userData99: string | undefined;


    userData100: string | undefined;

}
