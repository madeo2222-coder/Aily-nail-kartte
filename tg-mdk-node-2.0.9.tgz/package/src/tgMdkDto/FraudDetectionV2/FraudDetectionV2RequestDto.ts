import {FraudDetectionV2CardDto} from "./FraudDetectionV2CardDto.js";
import {FraudDetectionV2BankAccountDto} from "./FraudDetectionV2BankAccountDto.js";
import {FraudDetectionV2RiskDto} from "./FraudDetectionV2RiskDto.js";
import {FraudDetectionV2ThreeDSecureDto} from "./FraudDetectionV2ThreeDSecureDto.js";
import {FraudDetectionV2CustomerDto} from "./FraudDetectionV2CustomerDto.js";
import {FraudDetectionV2BillingDto} from "./FraudDetectionV2BillingDto.js";
import {FraudDetectionV2ShippingDto} from "./FraudDetectionV2ShippingDto.js";
import {FraudDetectionV2CorporateDto} from "./FraudDetectionV2CorporateDto.js";
import {FraudDetectionV2CartDto} from "./FraudDetectionV2CartDto.js";
import {FraudDetectionV2GiftCardDto} from "./FraudDetectionV2GiftCardDto.js";
import {FraudDetectionV2AirlineDto} from "./FraudDetectionV2AirlineDto.js";


export class FraudDetectionV2RequestDto {


    fraudDetectionOnly: string | undefined;


    fraudDetectionMode: string | undefined;


    targetServiceTypeCd: string | undefined;


    targetOrderId: string | undefined;


    merchantTransactionId: string | undefined;


    transactionCategory: string | undefined;


    amount: string | undefined;


    currency: string | undefined;


    paymentBrand: string | undefined;


    card: FraudDetectionV2CardDto | undefined;


    bankAccount: FraudDetectionV2BankAccountDto | undefined;


    taxAmount: string | undefined;


    risk: FraudDetectionV2RiskDto | undefined;


    threeDSecure: FraudDetectionV2ThreeDSecureDto | undefined;


    customer: FraudDetectionV2CustomerDto | undefined;


    billing: FraudDetectionV2BillingDto | undefined;


    shipping: FraudDetectionV2ShippingDto | undefined;


    corporate: FraudDetectionV2CorporateDto | undefined;


    cart: FraudDetectionV2CartDto | undefined;


    giftCard: FraudDetectionV2GiftCardDto | undefined;


    airline: FraudDetectionV2AirlineDto | undefined;

}
