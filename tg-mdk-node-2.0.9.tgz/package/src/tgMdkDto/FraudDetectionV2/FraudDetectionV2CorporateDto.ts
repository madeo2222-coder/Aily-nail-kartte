export class FraudDetectionV2CorporateDto {


    address: string | undefined;


    city: string | undefined;


    description: string | undefined;


    fax: string | undefined;


    name: string | undefined;


    phone: string | undefined;


    postboxNumber: string | undefined;


    postCode: string | undefined;


    purchase: string | undefined;


    state: string | undefined;


    street: string | undefined;


    country: string | undefined;


    suite: string | undefined;

}
