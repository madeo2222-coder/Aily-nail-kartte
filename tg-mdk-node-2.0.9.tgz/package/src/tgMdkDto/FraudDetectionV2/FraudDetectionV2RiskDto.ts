import {FraudDetectionV2ParametersDto} from "./FraudDetectionV2ParametersDto.js";


export class FraudDetectionV2RiskDto {


    serviceId: string | undefined;


    amount: string | undefined;


    orderTimestamp: string | undefined;


    merchantWebsite: string | undefined;


    accountToken: string | undefined;


    parameters: FraudDetectionV2ParametersDto | undefined;

}
