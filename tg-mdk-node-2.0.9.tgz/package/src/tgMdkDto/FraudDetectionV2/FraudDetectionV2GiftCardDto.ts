export class FraudDetectionV2GiftCardDto {


    message: string | undefined;


    type: string | undefined;

}
