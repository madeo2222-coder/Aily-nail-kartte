export class FraudDetectionV2PassengerDto {


    checkDigit: string | undefined;


    dob: string | undefined;


    email: string | undefined;


    frequentFlyerNumber: string | undefined;


    name: string | undefined;


    phone: string | undefined;


    status: string | undefined;


    ticketNumber: string | undefined;


    ticketRestricted: string | undefined;


    type: string | undefined;


    legs1AirlineName: string | undefined;


    legs1AirlineCode: string | undefined;


    legs1ArrivalAirport: string | undefined;


    legs1ArrivalCountry: string | undefined;


    legs1ArrivalDate: string | undefined;


    legs1ArrivalTime: string | undefined;


    legs1CarrierCode: string | undefined;


    legs1ClassOfService: string | undefined;


    legs1CouponNumber: string | undefined;


    legs1DepartureAirport: string | undefined;


    legs1DepartureCountry: string | undefined;


    legs1DepartureDate: string | undefined;


    legs1DepartureTime: string | undefined;


    legs1DepartureTaxAmount: string | undefined;


    legs1ExchangeTicketNum: string | undefined;


    legs1FareAmount: string | undefined;


    legs1FareBasis: string | undefined;


    legs1FeesAmount: string | undefined;


    legs1FlightNumber: string | undefined;


    legs1Restrictions: string | undefined;


    legs1StopOverAllowed: string | undefined;


    legs1TaxAmount: string | undefined;


    legs1TicketNumber: string | undefined;


    legs2AirlineName: string | undefined;


    legs2AirlineCode: string | undefined;


    legs2ArrivalAirport: string | undefined;


    legs2ArrivalCountry: string | undefined;


    legs2ArrivalDate: string | undefined;


    legs2ArrivalTime: string | undefined;


    legs2CarrierCode: string | undefined;


    legs2ClassOfService: string | undefined;


    legs2CouponNumber: string | undefined;


    legs2DepartureAirport: string | undefined;


    legs2DepartureCountry: string | undefined;


    legs2DepartureDate: string | undefined;


    legs2DepartureTime: string | undefined;


    legs2DepartureTaxAmount: string | undefined;


    legs2ExchangeTicketNum: string | undefined;


    legs2FareAmount: string | undefined;


    legs2FareBasis: string | undefined;


    legs2FeesAmount: string | undefined;


    legs2FlightNumber: string | undefined;


    legs2Restrictions: string | undefined;


    legs2StopOverAllowed: string | undefined;


    legs2TaxAmount: string | undefined;


    legs2TicketNumber: string | undefined;


    legs3AirlineName: string | undefined;


    legs3AirlineCode: string | undefined;


    legs3ArrivalAirport: string | undefined;


    legs3ArrivalCountry: string | undefined;


    legs3ArrivalDate: string | undefined;


    legs3ArrivalTime: string | undefined;


    legs3CarrierCode: string | undefined;


    legs3ClassOfService: string | undefined;


    legs3CouponNumber: string | undefined;


    legs3DepartureAirport: string | undefined;


    legs3DepartureCountry: string | undefined;


    legs3DepartureDate: string | undefined;


    legs3DepartureTime: string | undefined;


    legs3DepartureTaxAmount: string | undefined;


    legs3ExchangeTicketNum: string | undefined;


    legs3FareAmount: string | undefined;


    legs3FareBasis: string | undefined;


    legs3FeesAmount: string | undefined;


    legs3FlightNumber: string | undefined;


    legs3Restrictions: string | undefined;


    legs3StopOverAllowed: string | undefined;


    legs3TaxAmount: string | undefined;


    legs3TicketNumber: string | undefined;


    legs4AirlineName: string | undefined;


    legs4AirlineCode: string | undefined;


    legs4ArrivalAirport: string | undefined;


    legs4ArrivalCountry: string | undefined;


    legs4ArrivalDate: string | undefined;


    legs4ArrivalTime: string | undefined;


    legs4CarrierCode: string | undefined;


    legs4ClassOfService: string | undefined;


    legs4CouponNumber: string | undefined;


    legs4DepartureAirport: string | undefined;


    legs4DepartureCountry: string | undefined;


    legs4DepartureDate: string | undefined;


    legs4DepartureTime: string | undefined;


    legs4DepartureTaxAmount: string | undefined;


    legs4ExchangeTicketNum: string | undefined;


    legs4FareAmount: string | undefined;


    legs4FareBasis: string | undefined;


    legs4FeesAmount: string | undefined;


    legs4FlightNumber: string | undefined;


    legs4Restrictions: string | undefined;


    legs4StopOverAllowed: string | undefined;


    legs4TaxAmount: string | undefined;


    legs4TicketNumber: string | undefined;


    legs5AirlineName: string | undefined;


    legs5AirlineCode: string | undefined;


    legs5ArrivalAirport: string | undefined;


    legs5ArrivalCountry: string | undefined;


    legs5ArrivalDate: string | undefined;


    legs5ArrivalTime: string | undefined;


    legs5CarrierCode: string | undefined;


    legs5ClassOfService: string | undefined;


    legs5CouponNumber: string | undefined;


    legs5DepartureAirport: string | undefined;


    legs5DepartureCountry: string | undefined;


    legs5DepartureDate: string | undefined;


    legs5DepartureTime: string | undefined;


    legs5DepartureTaxAmount: string | undefined;


    legs5ExchangeTicketNum: string | undefined;


    legs5FareAmount: string | undefined;


    legs5FareBasis: string | undefined;


    legs5FeesAmount: string | undefined;


    legs5FlightNumber: string | undefined;


    legs5Restrictions: string | undefined;


    legs5StopOverAllowed: string | undefined;


    legs5TaxAmount: string | undefined;


    legs5TicketNumber: string | undefined;


    legs6AirlineName: string | undefined;


    legs6AirlineCode: string | undefined;


    legs6ArrivalAirport: string | undefined;


    legs6ArrivalCountry: string | undefined;


    legs6ArrivalDate: string | undefined;


    legs6ArrivalTime: string | undefined;


    legs6CarrierCode: string | undefined;


    legs6ClassOfService: string | undefined;


    legs6CouponNumber: string | undefined;


    legs6DepartureAirport: string | undefined;


    legs6DepartureCountry: string | undefined;


    legs6DepartureDate: string | undefined;


    legs6DepartureTime: string | undefined;


    legs6DepartureTaxAmount: string | undefined;


    legs6ExchangeTicketNum: string | undefined;


    legs6FareAmount: string | undefined;


    legs6FareBasis: string | undefined;


    legs6FeesAmount: string | undefined;


    legs6FlightNumber: string | undefined;


    legs6Restrictions: string | undefined;


    legs6StopOverAllowed: string | undefined;


    legs6TaxAmount: string | undefined;


    legs6TicketNumber: string | undefined;


    legs7AirlineName: string | undefined;


    legs7AirlineCode: string | undefined;


    legs7ArrivalAirport: string | undefined;


    legs7ArrivalCountry: string | undefined;


    legs7ArrivalDate: string | undefined;


    legs7ArrivalTime: string | undefined;


    legs7CarrierCode: string | undefined;


    legs7ClassOfService: string | undefined;


    legs7CouponNumber: string | undefined;


    legs7DepartureAirport: string | undefined;


    legs7DepartureCountry: string | undefined;


    legs7DepartureDate: string | undefined;


    legs7DepartureTime: string | undefined;


    legs7DepartureTaxAmount: string | undefined;


    legs7ExchangeTicketNum: string | undefined;


    legs7FareAmount: string | undefined;


    legs7FareBasis: string | undefined;


    legs7FeesAmount: string | undefined;


    legs7FlightNumber: string | undefined;


    legs7Restrictions: string | undefined;


    legs7StopOverAllowed: string | undefined;


    legs7TaxAmount: string | undefined;


    legs7TicketNumber: string | undefined;


    legs8AirlineName: string | undefined;


    legs8AirlineCode: string | undefined;


    legs8ArrivalAirport: string | undefined;


    legs8ArrivalCountry: string | undefined;


    legs8ArrivalDate: string | undefined;


    legs8ArrivalTime: string | undefined;


    legs8CarrierCode: string | undefined;


    legs8ClassOfService: string | undefined;


    legs8CouponNumber: string | undefined;


    legs8DepartureAirport: string | undefined;


    legs8DepartureCountry: string | undefined;


    legs8DepartureDate: string | undefined;


    legs8DepartureTime: string | undefined;


    legs8DepartureTaxAmount: string | undefined;


    legs8ExchangeTicketNum: string | undefined;


    legs8FareAmount: string | undefined;


    legs8FareBasis: string | undefined;


    legs8FeesAmount: string | undefined;


    legs8FlightNumber: string | undefined;


    legs8Restrictions: string | undefined;


    legs8StopOverAllowed: string | undefined;


    legs8TaxAmount: string | undefined;


    legs8TicketNumber: string | undefined;


    legs9AirlineName: string | undefined;


    legs9AirlineCode: string | undefined;


    legs9ArrivalAirport: string | undefined;


    legs9ArrivalCountry: string | undefined;


    legs9ArrivalDate: string | undefined;


    legs9ArrivalTime: string | undefined;


    legs9CarrierCode: string | undefined;


    legs9ClassOfService: string | undefined;


    legs9CouponNumber: string | undefined;


    legs9DepartureAirport: string | undefined;


    legs9DepartureCountry: string | undefined;


    legs9DepartureDate: string | undefined;


    legs9DepartureTime: string | undefined;


    legs9DepartureTaxAmount: string | undefined;


    legs9ExchangeTicketNum: string | undefined;


    legs9FareAmount: string | undefined;


    legs9FareBasis: string | undefined;


    legs9FeesAmount: string | undefined;


    legs9FlightNumber: string | undefined;


    legs9Restrictions: string | undefined;


    legs9StopOverAllowed: string | undefined;


    legs9TaxAmount: string | undefined;


    legs9TicketNumber: string | undefined;


    legs10AirlineName: string | undefined;


    legs10AirlineCode: string | undefined;


    legs10ArrivalAirport: string | undefined;


    legs10ArrivalCountry: string | undefined;


    legs10ArrivalDate: string | undefined;


    legs10ArrivalTime: string | undefined;


    legs10CarrierCode: string | undefined;


    legs10ClassOfService: string | undefined;


    legs10CouponNumber: string | undefined;


    legs10DepartureAirport: string | undefined;


    legs10DepartureCountry: string | undefined;


    legs10DepartureDate: string | undefined;


    legs10DepartureTime: string | undefined;


    legs10DepartureTaxAmount: string | undefined;


    legs10ExchangeTicketNum: string | undefined;


    legs10FareAmount: string | undefined;


    legs10FareBasis: string | undefined;


    legs10FeesAmount: string | undefined;


    legs10FlightNumber: string | undefined;


    legs10Restrictions: string | undefined;


    legs10StopOverAllowed: string | undefined;


    legs10TaxAmount: string | undefined;


    legs10TicketNumber: string | undefined;


}
