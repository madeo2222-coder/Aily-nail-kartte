export class FraudDetectionV2ThreeDSecureDto {


    eci: string | undefined;

}
