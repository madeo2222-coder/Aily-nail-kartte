export class FraudDetectionV2ItemDto {


    quantity: string | undefined;


    partNumber: string | undefined;


    productCode: string | undefined;


    sku: string | undefined;


    merchantItemId: string | undefined;


    description: string | undefined;


    originalPrice: string | undefined;


    shippingTrackingNumber: string | undefined;


    name: string | undefined;


    discount: string | undefined;


    giftMessage: string | undefined;


    shippingInstructions: string | undefined;


    shippingMethod: string | undefined;


    type: string | undefined;


    recipientAddress: string | undefined;


    recipientApartment: string | undefined;


    recipientCity: string | undefined;


    recipientCountry: string | undefined;


    recipientEmail: string | undefined;


    recipientFirstName: string | undefined;


    recipientLastName: string | undefined;


    recipientMiddleName: string | undefined;


    recipientPhone: string | undefined;


    recipientPostcode: string | undefined;


    recipientSalutation: string | undefined;


    recipientState: string | undefined;


    recipientStreet: string | undefined;

}
