export class FraudDetectionV2CardDto {


    number: string | undefined;


    expiryMonth: string | undefined;


    expiryYear: string | undefined;

}
