import {FraudDetectionV2ItemDto} from "./FraudDetectionV2ItemDto.js";


export class FraudDetectionV2CartDto {


    items: FraudDetectionV2ItemDto[] | undefined;

}
