import type {IRequestDto} from "../../tgMdk/IRequestDto.js";
import {AbstractPaymentRequestDto} from "../AbstractPaymentRequestDto.js";


export class CvsAuthorizeRequestDto extends AbstractPaymentRequestDto implements IRequestDto {
    readonly serviceType: string = "cvs";
    readonly serviceCommand: string = "Authorize";


    serviceOptionType: string | undefined;


    orderId: string | undefined;


    amount: string | undefined;


    name1: string | undefined;


    name2: string | undefined;


    kana: string | undefined;


    telNo: string | undefined;


    payLimit: string | undefined;


    paymentType: string | undefined;


    free1: string | undefined;


    free2: string | undefined;


    pushUrl: string | undefined;


    payLimitHhmm: string | undefined;

    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }

}
