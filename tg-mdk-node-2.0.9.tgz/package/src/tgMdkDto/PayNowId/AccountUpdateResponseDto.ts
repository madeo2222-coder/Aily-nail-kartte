import {AbstractPayNowIdResponseDto} from "./AbstractPayNowIdResponseDto.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class AccountUpdateResponseDto extends AbstractPayNowIdResponseDto implements IResponseDto {

}
