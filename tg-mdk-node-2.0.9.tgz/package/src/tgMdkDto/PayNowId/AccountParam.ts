import {CardParam} from "./CardParam.js";
import {RecurringChargeParam} from "./RecurringChargeParam.js";
import {BankAccountParam} from "./BankAccountParam.js";
import {AccountBasicParam} from "./AccountBasicParam.js";


export class AccountParam {


    accountId: string | undefined;


    onetimeToken: string | undefined;


    onetimeTokenType: string | undefined;


    originalAccountId: string | undefined;


    payNowId: string | undefined;


    transData: string | undefined;


    accountBasicParam: AccountBasicParam | undefined;


    cardParam: CardParam | undefined;


    recurringChargeParam: RecurringChargeParam | undefined;


    bankAccountParam: BankAccountParam | undefined;

}
