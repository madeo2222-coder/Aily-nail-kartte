export class BankAccountParam {


    bankCode: string | undefined;


    branchCode: string | undefined;


    accountType: string | undefined;


    accountNumber: string | undefined;


    accountManageType: string | undefined;


    rejectBankAccount: string | undefined;

}
