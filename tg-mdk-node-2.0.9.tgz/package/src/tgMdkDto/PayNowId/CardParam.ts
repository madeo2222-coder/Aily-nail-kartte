export class CardParam {


    cardId: string | undefined;


    defaultCard: string | undefined;


    defaultCardId: string | undefined;


    updater: string | undefined;


    cardNumber: string | undefined;


    cardExpire: string | undefined;


    securityCode: string | undefined;


    cardholderName: string | undefined;


    token: string | undefined;


    cardNumberMaskType: string | undefined;


    withAuthorize: string | undefined;

}
