export class CardInfo {


    cardId: string | undefined;


    cardNumber: string | undefined;


    cardExpire: string | undefined;


    cardholderName: string | undefined;


    defaultCard: string | undefined;


    acquireCode3: string | undefined;


    kindCode: string | undefined;


    originalCardId: string | undefined;

}
