import {Account} from "./Account.js";
import {OptionResults} from "./OptionResults.js";


export class PayNowIdResponse {


    processId: string | undefined;


    status: string | undefined;


    message: string | undefined;


    account: Account | undefined;


    optionResults: [OptionResults] | undefined;

}
