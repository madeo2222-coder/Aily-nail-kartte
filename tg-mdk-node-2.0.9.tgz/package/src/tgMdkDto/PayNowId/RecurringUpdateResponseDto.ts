import {AbstractPayNowIdResponseDto} from "./AbstractPayNowIdResponseDto.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class RecurringUpdateResponseDto extends AbstractPayNowIdResponseDto implements IResponseDto {

}
