import {AbstractPayNowIdResponseDto} from "./AbstractPayNowIdResponseDto.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class ChargeUpdateResponseDto extends AbstractPayNowIdResponseDto implements IResponseDto {

}
