import {AccountParam} from "./AccountParam.js";
import {ChargeParam} from "./ChargeParam.js";
import {OrderParam} from "./OrderParam.js";


export class PayNowIdParam {


    accountParam: AccountParam | undefined;


    chargeParam: ChargeParam | undefined;


    orderParam: OrderParam | undefined;


    tanking: string | undefined;


    freeKey: string | undefined;


    memo1: string | undefined;


    receiptData: string | undefined;


    token: string | undefined;

}
