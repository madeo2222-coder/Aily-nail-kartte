export class OptionResults {


    options: [string] | undefined;

}
