import {AbstractPayNowIdResponseDto} from "./AbstractPayNowIdResponseDto.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class RecurringAddResponseDto extends AbstractPayNowIdResponseDto implements IResponseDto {

}
