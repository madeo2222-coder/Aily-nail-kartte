export class ChargeParam {


    groupId: string | undefined;


    groupName: string | undefined;


    type: string | undefined;


    oneTimeAmount: string | undefined;


    amount: string | undefined;


    chargeType: string | undefined;


    schedule: string | undefined;


    salesDay: string | undefined;


    acquireCode: string | undefined;

}
