export class AccountInfo {


    accountInfoId: string | undefined;


    accountType: string | undefined;


    defaultAccount: string | undefined;


    recipient: string | undefined;


    zip: string | undefined;


    address: string | undefined;


    tel: string | undefined;

}
