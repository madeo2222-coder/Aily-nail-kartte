import {AbstractPayNowIdResponseDto} from "./AbstractPayNowIdResponseDto.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class RecurringGetResponseDto extends AbstractPayNowIdResponseDto implements IResponseDto {

}
