export class PayNowIdConstants {

    /** サービスタイプ(account) */
    static readonly SERVICE_TYPE_ACCOUNT: string = "account";
    /** サービスタイプ(charge) */
    static readonly SERVICE_TYPE_CHARGE: string = "charge";
    /** サービスタイプ(recurring) */
    static readonly SERVICE_TYPE_RECURRING: string = "recurring";
    /** サービスタイプ(cardinfo) */
    static readonly SERVICE_TYPE_CARDINFO: string = "cardinfo";
    /** サービスタイプ(bankAccount) */
    static readonly SERVICE_TYPE_BANKACCOUNT: string = "bankAccount";
    /** サービスコマンド(Add) */
    static readonly SERVICE_COMMAND_ADD: string = "Add";
    /** サービスコマンド(Update) */
    static readonly SERVICE_COMMAND_UPDATE: string = "Update";
    /** サービスコマンド(Delete) */
    static readonly SERVICE_COMMAND_DELETE: string = "Delete";
    /** サービスコマンド(Restore) */
    static readonly SERVICE_COMMAND_RESTORE: string = "Restore";
    /** サービスコマンド(Get) */
    static readonly SERVICE_COMMAND_GET: string = "Get";
    /** サービスコマンド(Link) */
    static readonly SERVICE_COMMAND_LINK: string = "Link";

}