import {AccountBasic} from "./AccountBasic.js";
import {AccountInfo} from "./AccountInfo.js";
import {RecurringCharge} from "./RecurringCharge.js";
import {BankAccountInfo} from "./BankAccountInfo.js";
import {CardInfo} from "./CardInfo.js";


export class Account {


    accountId: string | undefined;


    onetimeToken: string | undefined;


    onetimeTokenExpire: string | undefined;


    transData: string | undefined;


    accountBasic: AccountBasic | undefined;


    accountInfo: [AccountInfo] | undefined;


    cardInfo: [CardInfo] | undefined;


    recurringCharge: [RecurringCharge] | undefined;


    bankAccountInfo: BankAccountInfo | undefined;

}
