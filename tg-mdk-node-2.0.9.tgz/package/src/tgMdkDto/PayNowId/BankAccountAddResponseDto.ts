import {AbstractPayNowIdResponseDto} from "./AbstractPayNowIdResponseDto.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class BankAccountAddResponseDto extends AbstractPayNowIdResponseDto implements IResponseDto {

}
