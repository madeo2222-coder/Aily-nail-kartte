export class AccountBasicParam {


    createDate: string | undefined;


    deleteDate: string | undefined;


    forceDeleteDate: string | undefined;


    deleteCardInfo: string | undefined;


    addCardInfo: string | undefined;


    deleteOriginalAccountId: string | undefined;


    defaultCardOnly: string | undefined;


    cleaningConfig: string | undefined;

}
