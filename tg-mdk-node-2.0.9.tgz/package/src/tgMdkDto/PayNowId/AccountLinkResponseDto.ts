import {AbstractPayNowIdResponseDto} from "./AbstractPayNowIdResponseDto.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class AccountLinkResponseDto extends AbstractPayNowIdResponseDto implements IResponseDto {

}
