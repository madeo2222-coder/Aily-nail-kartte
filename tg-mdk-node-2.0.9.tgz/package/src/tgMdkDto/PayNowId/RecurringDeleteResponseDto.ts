import {AbstractPayNowIdResponseDto} from "./AbstractPayNowIdResponseDto.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class RecurringDeleteResponseDto extends AbstractPayNowIdResponseDto implements IResponseDto {

}
