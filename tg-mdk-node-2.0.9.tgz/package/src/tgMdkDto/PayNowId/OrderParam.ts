export class OrderParam {


    originalOrderId: string | undefined;


    cleaningMerchantId: string | undefined;

}
