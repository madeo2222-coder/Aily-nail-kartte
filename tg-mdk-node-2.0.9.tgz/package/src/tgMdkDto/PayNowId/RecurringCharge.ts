export class RecurringCharge {


    groupId: string | undefined;


    cardId: string | undefined;

}
