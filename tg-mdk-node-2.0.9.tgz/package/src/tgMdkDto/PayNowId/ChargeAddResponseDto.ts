import {AbstractPayNowIdResponseDto} from "./AbstractPayNowIdResponseDto.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class ChargeAddResponseDto extends AbstractPayNowIdResponseDto implements IResponseDto {

}
