import {AbstractPayNowIdResponseDto} from "./AbstractPayNowIdResponseDto.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class AccountRestoreResponseDto extends AbstractPayNowIdResponseDto implements IResponseDto {

}
