import {AbstractPayNowIdResponseDto} from "./AbstractPayNowIdResponseDto.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class AccountCopyResponseDto extends AbstractPayNowIdResponseDto implements IResponseDto {

}
