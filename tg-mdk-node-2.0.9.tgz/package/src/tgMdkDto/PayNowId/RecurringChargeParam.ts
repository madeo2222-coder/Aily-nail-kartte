export class RecurringChargeParam {


    groupId: string | undefined;


    startDate: string | undefined;


    endDate: string | undefined;


    finalCharge: string | undefined;


    oneTimeAmount: string | undefined;


    amount: string | undefined;


    recurringMemo1: string | undefined;


    recurringMemo2: string | undefined;


    recurringMemo3: string | undefined;


    useChargeOption: string | undefined;


    salesDay: string | undefined;


    acquireCode: string | undefined;

}
