import {MdkDtoBase} from "../MdkDtoBase.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";
import {PayNowIdResponse} from "./PayNowIdResponse.js";


export class AbstractPayNowIdResponseDto extends MdkDtoBase implements IResponseDto {

    private _resultJson: string | undefined;


    serviceType: string | undefined;


    mstatus: string | undefined;


    vResultCode: string | undefined;


    merrMsg: string | undefined;


    marchTxn: string | undefined;


    custTxn: string | undefined;


    txnVersion: string | undefined;


    payNowIdResponse: PayNowIdResponse | undefined;

    get resultJson(): string | undefined {
        return this._resultJson;
    }

    set resultJson(value: string) {
        this._resultJson = value;
    }

}
