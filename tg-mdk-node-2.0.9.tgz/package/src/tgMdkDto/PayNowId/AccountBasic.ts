export class AccountBasic {


    lastName: string | undefined;


    lastKanaName: string | undefined;


    firstName: string | undefined;


    firstKanaName: string | undefined;


    mailAddress: string | undefined;


    createDate: string | undefined;


    deleteDate: string | undefined;

}
