import {AbstractPayNowIdResponseDto} from "./AbstractPayNowIdResponseDto.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class AccountAddResponseDto extends AbstractPayNowIdResponseDto implements IResponseDto {

}
