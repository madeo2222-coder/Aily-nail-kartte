export class BankAccountInfo {


    bankCode: string | undefined;


    branchCode: string | undefined;


    accountType: string | undefined;


    accountNumber: string | undefined;


    accountName: string | undefined;

}
