import {AbstractPayNowIdResponseDto} from "./AbstractPayNowIdResponseDto.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class AccountDeleteResponseDto extends AbstractPayNowIdResponseDto implements IResponseDto {

}
