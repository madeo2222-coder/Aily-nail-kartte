import {AbstractPaymentRequestDto} from "../AbstractPaymentRequestDto.js";
import type {IRequestDto} from "../../tgMdk/IRequestDto.js";


export class CarrierReAuthorizeRequestDto extends AbstractPaymentRequestDto implements IRequestDto {
    readonly serviceType: string = "carrier";
    readonly serviceCommand: string = "ReAuthorize";


    orderId: string | undefined;


    originalOrderId: string | undefined;


    serviceOptionType: string | undefined;


    withCapture: string | undefined;


    amount: string | undefined;


    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }

}