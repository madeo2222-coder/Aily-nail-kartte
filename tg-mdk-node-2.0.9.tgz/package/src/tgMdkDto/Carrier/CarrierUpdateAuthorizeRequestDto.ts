import {AbstractPaymentRequestDto} from "../AbstractPaymentRequestDto.js";
import type {IRequestDto} from "../../tgMdk/IRequestDto.js";


export class CarrierUpdateAuthorizeRequestDto extends AbstractPaymentRequestDto implements IRequestDto {
    readonly serviceType: string = "carrier";
    readonly serviceCommand: string = "UpdateAuthorize";


    orderId: string | undefined;


    serviceOptionType: string | undefined;


    amount: string | undefined;


    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }

}