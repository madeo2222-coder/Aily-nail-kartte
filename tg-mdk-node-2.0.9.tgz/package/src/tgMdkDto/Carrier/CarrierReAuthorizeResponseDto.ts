import {MdkDtoBase} from "../MdkDtoBase.js";
import {PayNowIdResponse} from "../PayNowId/PayNowIdResponse.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class CarrierReAuthorizeResponseDto extends MdkDtoBase implements IResponseDto {

    private _resultJson: string | undefined;


    serviceType: string | undefined;


    mstatus: string | undefined;


    vResultCode: string | undefined;


    merrMsg: string | undefined;


    marchTxn: string | undefined;


    orderId: string | undefined;


    originalOrderId: string | undefined;


    crOrderId: string | undefined;


    custTxn: string | undefined;


    txnVersion: string | undefined;


    txnTime: string | undefined;


    payNowIdResponse: PayNowIdResponse | undefined;

    get resultJson(): string | undefined {
        return this._resultJson;
    }

    set resultJson(value: string) {
        this._resultJson = value;
    }

}
