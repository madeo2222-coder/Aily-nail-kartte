import {AbstractPaymentRequestDto} from "../AbstractPaymentRequestDto.js";
import type {IRequestDto} from "../../tgMdk/IRequestDto.js";


export class CarrierAuthorizeRequestDto extends AbstractPaymentRequestDto implements IRequestDto {
    readonly serviceType: string = "carrier";
    readonly serviceCommand: string = "Authorize";


    orderId: string | undefined;


    serviceOptionType: string | undefined;


    amount: string | undefined;


    terminalKind: string | undefined;


    itemType: string | undefined;


    accountingType: string | undefined;


    withCapture: string | undefined;


    d3Flag: string | undefined;


    mpFirstDate: string | undefined;


    mpDay: string | undefined;


    itemId: string | undefined;


    itemInfo: string | undefined;


    successUrl: string | undefined;


    cancelUrl: string | undefined;


    errorUrl: string | undefined;


    pushUrl: string | undefined;


    openId: string | undefined;


    sbUid: string | undefined;


    fletsArea: string | undefined;


    loginAuId: string | undefined;


    auId: string | undefined;


    paymentAuthenticationType: string | undefined;


    billingToken: string | undefined;


    idauth: string | undefined;


    storeId: string | undefined;


    termId: string | undefined;


    receiptNo: string | undefined;


    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }

}