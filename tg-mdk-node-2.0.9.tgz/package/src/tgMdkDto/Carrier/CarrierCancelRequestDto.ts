import {AbstractPaymentRequestDto} from "../AbstractPaymentRequestDto.js";
import type {IRequestDto} from "../../tgMdk/IRequestDto.js";


export class CarrierCancelRequestDto extends AbstractPaymentRequestDto implements IRequestDto {
    readonly serviceType: string = "carrier";
    readonly serviceCommand: string = "Cancel";


    orderId: string | undefined;


    serviceOptionType: string | undefined;


    cancelMonth: string | undefined;


    amount: string | undefined;


    storeId: string | undefined;


    termId: string | undefined;


    receiptNo: string | undefined;


    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }

}