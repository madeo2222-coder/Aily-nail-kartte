import type {IRequestDto} from "../../tgMdk/IRequestDto.js";
import {AbstractPaymentRequestDto} from "../AbstractPaymentRequestDto.js";


export class AlipayxRefundRequestDto extends AbstractPaymentRequestDto implements IRequestDto {
    readonly serviceType: string = "alipayx";
    readonly serviceCommand: string = "Refund";

    orderId: string | undefined;


    serviceOptionType: string | undefined;


    amount: string | undefined;


    reason: string | undefined;


    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }
}

