import type {IRequestDto} from "../../tgMdk/IRequestDto.js";
import {AbstractPaymentRequestDto} from "../AbstractPaymentRequestDto.js";


export class AlipayxAuthorizeRequestDto extends AbstractPaymentRequestDto implements IRequestDto {
    readonly serviceType: string = "alipayx";
    readonly serviceCommand: string = "Authorize";

    orderId: string | undefined;


    serviceOptionType: string | undefined;


    amount: string | undefined;


    withCapture: string | undefined;


    responseType: string | undefined;


    identityCode: string | undefined;


    orderTitle: string | undefined;


    orderDetail: string | undefined;


    storeId: string | undefined;


    storeName: string | undefined;


    terminalId: string | undefined;


    operatorId: string | undefined;


    scancodeType: string | undefined;


    deviceType: string | undefined;


    userAgent: string | undefined;


    successRedirectUrl: string | undefined;


    successUrl: string | undefined;


    errorUrl: string | undefined;


    pushUrl: string | undefined;


    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }
}

