import type {IRequestDto} from "../../tgMdk/IRequestDto.js";
import {AbstractPaymentRequestDto} from "../AbstractPaymentRequestDto.js";


export class AlipayxConfirmRequestDto extends AbstractPaymentRequestDto implements IRequestDto {
    readonly serviceType: string = "alipayx";
    readonly serviceCommand: string = "Confirm";

    orderId: string | undefined;


    serviceOptionType: string | undefined;


    responseType: string | undefined;


    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }
}

