import {MdkDtoBase} from "../MdkDtoBase.js";
import {PayNowIdResponse} from "../PayNowId/PayNowIdResponse.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class AmazonpayUpdateConsentResponseDto extends MdkDtoBase implements IResponseDto {


    private _resultJson: string | undefined;


    serviceType: string | undefined;


    mstatus: string | undefined;


    vResultCode: string | undefined;


    merrMsg: string | undefined;


    marchTxn: string | undefined;


    orderId: string | undefined;


    custTxn: string | undefined;


    txnVersion: string | undefined;


    centerResponseDatetime: string | undefined;


    centerOrderId: string | undefined;


    get resultJson(): string | undefined {
        return this._resultJson;
    }

    set resultJson(value: string) {
        this._resultJson = value;
    }

    payNowIdResponse: PayNowIdResponse | undefined;
}

