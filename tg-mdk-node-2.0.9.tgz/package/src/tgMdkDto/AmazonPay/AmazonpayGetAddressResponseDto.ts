import {MdkDtoBase} from "../MdkDtoBase.js";
import {PayNowIdResponse} from "../PayNowId/PayNowIdResponse.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class AmazonpayGetAddressResponseDto extends MdkDtoBase implements IResponseDto {


    private _resultJson: string | undefined;


    serviceType: string | undefined;


    mstatus: string | undefined;


    vResultCode: string | undefined;


    merrMsg: string | undefined;


    orderId: string | undefined;


    txnVersion: string | undefined;


    centerResponseDatetime: string | undefined;


    shippingName: string | undefined;


    shippingPhone: string | undefined;


    shippingAddress1: string | undefined;


    shippingAddress2: string | undefined;


    shippingAddress3: string | undefined;


    shippingPrefecture: string | undefined;


    shippingPostalCode: string | undefined;


    buyerId: string | undefined;


    buyerEmail: string | undefined;


    buyerName: string | undefined;


    buyerPhoneNumber: string | undefined;


    paymentPreferences: string | undefined;


    billingAddress1: string | undefined;


    billingAddress2: string | undefined;


    billingAddress3: string | undefined;


    billingPrefecture: string | undefined;


    billingPostalCode: string | undefined;


    payRedirectUrl: string | undefined;


    checkoutSessionId: string | undefined;


    get resultJson(): string | undefined {
        return this._resultJson;
    }

    set resultJson(value: string) {
        this._resultJson = value;
    }

    payNowIdResponse: PayNowIdResponse | undefined;
}

