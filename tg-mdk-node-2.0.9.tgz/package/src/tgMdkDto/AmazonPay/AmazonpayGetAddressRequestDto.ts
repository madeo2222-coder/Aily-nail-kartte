import type {IRequestDto} from "../../tgMdk/IRequestDto.js";
import {AbstractPaymentRequestDto} from "../AbstractPaymentRequestDto.js";


export class AmazonpayGetAddressRequestDto extends AbstractPaymentRequestDto implements IRequestDto {
    readonly serviceType: string = "amazonpay";
    readonly serviceCommand: string = "GetAddress";


    orderId: string | undefined;


    addInfoRespFlag: string | undefined;


    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }
}

