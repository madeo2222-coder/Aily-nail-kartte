import type {IRequestDto} from "../../tgMdk/IRequestDto.js";
import {AbstractPaymentRequestDto} from "../AbstractPaymentRequestDto.js";


export class PaypayTerminateRequestDto extends AbstractPaymentRequestDto implements IRequestDto {
    readonly serviceType: string = "paypay";
    readonly serviceCommand: string = "Terminate";


    orderId: string | undefined;


    serviceOptionType: string | undefined;


    force: string | undefined;


    successUrl: string | undefined;


    cancelUrl: string | undefined;


    errorUrl: string | undefined;


    pushUrl: string | undefined;


    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }

}

