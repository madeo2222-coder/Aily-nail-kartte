import {MdkDtoBase} from "../MdkDtoBase.js";
import {PayNowIdResponse} from "../PayNowId/PayNowIdResponse.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";


export class PaypayReAuthorizeResponseDto extends MdkDtoBase implements IResponseDto {


    private _resultJson: string | undefined;


    serviceType: string | undefined;


    mstatus: string | undefined;


    vResultCode: string | undefined;


    merrMsg: string | undefined;


    marchTxn: string | undefined;


    orderId: string | undefined;


    custTxn: string | undefined;


    txnVersion: string | undefined;


    paypayOrderId: string | undefined;


    paypayPaidDatetime: string | undefined;


    originalOrderId: string | undefined;


    centerOrderId: string | undefined;


    userKey: string | undefined;


    get resultJson(): string | undefined {
        return this._resultJson;
    }

    set resultJson(value: string) {
        this._resultJson = value;
    }


    payNowIdResponse: PayNowIdResponse | undefined;

}

