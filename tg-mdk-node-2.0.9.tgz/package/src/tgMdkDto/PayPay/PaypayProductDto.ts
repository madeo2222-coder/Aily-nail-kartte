export class PaypayProductDto {

    productId: string | undefined;

    productName: string | undefined;

    quantity: string | undefined;

    price: string | undefined;

    discountPrice: string | undefined;

    productCategoryCode: string | undefined;

}