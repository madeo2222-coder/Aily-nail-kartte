import type {IRequestDto} from "../../tgMdk/IRequestDto.js";
import {AbstractPaymentRequestDto} from "../AbstractPaymentRequestDto.js";


export class PaypayReAuthorizeRequestDto extends AbstractPaymentRequestDto implements IRequestDto {
    readonly serviceType: string = "paypay";
    readonly serviceCommand: string = "ReAuthorize";


    orderId: string | undefined;


    serviceOptionType: string | undefined;


    originalOrderId: string | undefined;


    amount: string | undefined;


    itemId: string | undefined;


    itemName: string | undefined;


    nsfRecoveryFlag: string | undefined;


    nsfRecoveryExpiredDatetime: string | undefined;


    pushUrl: string | undefined;


    storeId: string | undefined;


    terminalId: string | undefined;


    orderDescription: string | undefined;


    withCapture: string | undefined;


    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }

}

