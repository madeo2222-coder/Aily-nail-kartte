import {BankFinancialInstInfo} from "./BankFinancialInstInfo.js";


export class Masters {


    bankFinancialInstInfo: BankFinancialInstInfo[] | undefined;

}
