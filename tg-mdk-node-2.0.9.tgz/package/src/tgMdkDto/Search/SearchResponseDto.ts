import {MdkDtoBase} from "../MdkDtoBase.js";
import type {IResponseDto} from "../../tgMdk/IResponseDto.js";
import {MasterInfos} from "./MasterInfos.js";
import {OrderInfos} from "./OrderInfos.js";


export class SearchResponseDto extends MdkDtoBase implements IResponseDto {

    private _resultJson: string | undefined;


    serviceType: string | undefined;


    mstatus: string | undefined;


    vResultCode: string | undefined;


    merrMsg: string | undefined;


    orderId: string | undefined;


    marchTxn: string | undefined;


    custTxn: string | undefined;


    txnVersion: string | undefined;


    overMaxCountFlag: string | undefined;


    masterInfos: MasterInfos | undefined;


    searchCount: string | undefined;


    orderInfos: OrderInfos | undefined;

    get resultJson(): string | undefined {
        return this._resultJson;
    }

    set resultJson(value: string) {
        this._resultJson = value;
    }

}
