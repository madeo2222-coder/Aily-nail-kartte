export class ProperOrderInfo {


    settlementMethod: string | undefined;


    settlementType: string | undefined;


    amount: string | undefined;


    authorizeAmount: string | undefined;


    balance: string | undefined;


    usedPoint: string | undefined;


    usePoint: string | undefined;


    givePoint: string | undefined;


    recruitCoupon: string | undefined;


    merchantCoupon: string | undefined;


    settlementLimit: string | undefined;


    forwardMailFlag: string | undefined;


    merchantMailAddr: string | undefined;


    cancelMailAddr: string | undefined;


    requestMailAddInfo: string | undefined;


    completeMailAddInfo: string | undefined;


    shopName: string | undefined;


    completeMailFlag: string | undefined;


    confirmScreenAddInfo: string | undefined;


    completeScreenAddInfo: string | undefined;


    screenTitle: string | undefined;


    completeReturnKind: string | undefined;


    completeReturnUrl: string | undefined;


    completeNoticeUrl: string | undefined;


    salesType: string | undefined;


    free: string | undefined;


    refundOrderCtlId: string | undefined;


    appUrl: string | undefined;


    orderKind: string | undefined;


    completeDatetime: string | undefined;


    reAuthorizeRedirectionUrl: string | undefined;


    transactionKind: string | undefined;


    userId: string | undefined;


    settlementId: string | undefined;


    reAuthAppUrl: string | undefined;


    cvsType: string | undefined;


    name1: string | undefined;


    name2: string | undefined;


    kana: string | undefined;


    telNo: string | undefined;


    mailAddr: string | undefined;


    free1: string | undefined;


    free2: string | undefined;


    payLimit: string | undefined;


    payLimitDatetime: string | undefined;


    receiptNo: string | undefined;


    paidDatetime: string | undefined;


    receivedDatetime: string | undefined;


    startTxn: string | undefined;


    dddMessageVersion: string | undefined;


    deviceChannel: string | undefined;


    accountType: string | undefined;


    authenticationIndicator: string | undefined;


    messageCategory: string | undefined;


    requestCurrencyUnit: string | undefined;


    cardExpire: string | undefined;


    tradUrl: string | undefined;


    invoiceId: string | undefined;


    payerId: string | undefined;


    paymentDatetime: string | undefined;


    merchantRedirectUri: string | undefined;


    totalAmount: string | undefined;


    walletAmount: string | undefined;


    cardAmount: string | undefined;


    cardOrderId: string | undefined;


    crServiceType: string | undefined;


    withCapture: string | undefined;


    accountingType: string | undefined;


    itemInfo: string | undefined;


    itemId: string | undefined;


    itemType: string | undefined;


    terminalKind: string | undefined;


    authorizeDatetime: string | undefined;


    captureDatetime: string | undefined;


    cancelDatetime: string | undefined;


    mpFirstDate: string | undefined;


    mpDay: string | undefined;


    mpStatus: string | undefined;


    mpOrderId: string | undefined;


    mpTxnStatusType: string | undefined;


    mpCaptureDatetime: string | undefined;


    mpCancelDatetime: string | undefined;


    mpTerminateDatetime: string | undefined;


    crOrderId: string | undefined;


    d3Flag: string | undefined;


    fletsArea: string | undefined;


    merchantRedirectionUrl: string | undefined;


    oricoOrderNo: string | undefined;


    userNo: string | undefined;


    itemName: string | undefined;


    itemName1: string | undefined;


    itemCount1: string | undefined;


    itemAmount1: string | undefined;


    itemName2: string | undefined;


    itemCount2: string | undefined;


    itemAmount2: string | undefined;


    itemName3: string | undefined;


    itemCount3: string | undefined;


    itemAmount3: string | undefined;


    itemName4: string | undefined;


    itemCount4: string | undefined;


    itemAmount4: string | undefined;


    itemName5: string | undefined;


    itemCount5: string | undefined;


    itemAmount5: string | undefined;


    totalItemAmount: string | undefined;


    totalCarriage: string | undefined;


    deposit: string | undefined;


    shippingZipCode: string | undefined;


    handlingContractNo: string | undefined;


    memberStoreNo: string | undefined;


    contractDocumentKbn: string | undefined;


    webDescriptionId: string | undefined;


    rakutenOrderId: string | undefined;


    rakutenConsentOrderId: string | undefined;


    customerId: string | undefined;


    recruitOrderId: string | undefined;


    linepayOrderId: string | undefined;


    itemAmount: string | undefined;


    masterpassOrderId: string | undefined;


    acquirerCode: string | undefined;


    cardNumber: string | undefined;


    jpoInformation: string | undefined;


    vaccDepositStatusType: string | undefined;


    transferExpiredDate: string | undefined;


    reconcileDate: string | undefined;


    totalDepositAmount: string | undefined;


    entryTransferName: string | undefined;


    entryTransferNumber: string | undefined;


    accountNumber: string | undefined;


    accountManageType: string | undefined;


    tenpayServiceType: string | undefined;


    itemDetail: string | undefined;


    itemLabel: string | undefined;


    tenpayOrderId: string | undefined;


    paypayOrderId: string | undefined;


    paypayServiceType: string | undefined;


    refundDatetime: string | undefined;


    terminateDatetime: string | undefined;


    userKey: string | undefined;


    alipayxServiceType: string | undefined;


    centerId: string | undefined;


    paymentSource: string | undefined;


    foreignAmount: string | undefined;


    foreignAmountCurrency: string | undefined;


    cvspayType: string | undefined;


    payType: string | undefined;


    cvspayOrderId: string | undefined;


    nissenTransactionId: string | undefined;


    lastAuthorResult: string | undefined;


    captureAmount: string | undefined;


    refundableAmount: string | undefined;


    centerOrderId: string | undefined;


    consentStatus: string | undefined;


    frequencyUnit: string | undefined;


    frequencyValue: string | undefined;


    merpayServiceType: string | undefined;


    consentAuthType: string | undefined;


    preapprovalId: string | undefined;


    eposOrderId: string | undefined;


    useCredit: string | undefined;


    useCoupon: string | undefined;


    odAmount: string | undefined;


    gatewayOrderId: string | undefined;


    cardBrand: string | undefined;


    cardLast4: string | undefined;


    cardInstallments: string | undefined;


    cardCvc: string | undefined;


    card3ds: string | undefined;


    cancelExpirationTime: string | undefined;


    captureExpirationTime: string | undefined;


    updateExpirationTime: string | undefined;


    extendAuthExpirationTime: string | undefined;


    payConfirmScreenType: string | undefined;


    onlinePaymentType: string | undefined;


    testEnvFlag: string | undefined;


    memberId: string | undefined;


    accountId: string | undefined;


    properTransactionInfo: string | undefined;

}
