export class BankFinancialInstInfo {


    bankCode: string | undefined;


    deviceCode: string | undefined;


    bankName: string | undefined;


    bankKana: string | undefined;


    bankIndexChar1: string | undefined;


    bankIndexChar2: string | undefined;


    startDatetime: string | undefined;

}
