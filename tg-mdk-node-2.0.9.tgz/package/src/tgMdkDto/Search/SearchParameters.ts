import {CommonSearchParameter} from "./CommonSearchParameter.js";


export class SearchParameters {

    constructor(common: CommonSearchParameter) {
        this.common = common;
    }


    common: CommonSearchParameter;

}
