import {OrderInfo} from "./OrderInfo.js";


export class OrderInfos {


    orderInfo: OrderInfo[] | undefined;

}
