import {Masters} from "./Masters.js";


export class MasterInfo {


    name: string | undefined;


    masters: Masters | undefined;

}
