import {ProperTransactionInfo} from "./ProperTransactionInfo.js";


export class TransactionInfo {


    txnId: string | undefined;


    command: string | undefined;


    mstatus: string | undefined;


    vResultCode: string | undefined;


    txnDatetime: string | undefined;


    amount: string | undefined;


    properTransactionInfo: ProperTransactionInfo | undefined;

}
