import {TransactionInfo} from "./TransactionInfo.js";


export class TransactionInfos {


    transactionInfo: TransactionInfo[] | undefined;

}
