import {MasterInfo} from "./MasterInfo.js";


export class MasterInfos {


    masterInfo: MasterInfo[] | undefined;

}
