export class SearchRange {


    from: string | undefined;


    to: string | undefined;

}
