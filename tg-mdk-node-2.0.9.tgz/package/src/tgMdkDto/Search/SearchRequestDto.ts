import {MdkDtoBase} from "../MdkDtoBase.js";
import type {IRequestDto} from "../../tgMdk/IRequestDto.js";
import {SearchParameters} from "./SearchParameters.js";


export class SearchRequestDto extends MdkDtoBase implements IRequestDto {
    readonly serviceType: string = "search";
    readonly serviceCommand: string = "Search";


    requestId: string | undefined;


    serviceTypeCd: string[] | undefined;


    newerFlag: string | undefined;


    containDummyFlag: string | undefined;


    maxCount: string | undefined;


    masterNames: string[] | undefined;


    searchParameters: SearchParameters | undefined;

    private _maskedLog: string | undefined;

    get maskedLog(): string | undefined {
        return this._maskedLog;
    }

    set maskedLog(value: string) {
        this._maskedLog = value;
    }

}
