import {SearchRange} from "./SearchRange.js";


export class CommonSearchParameter {

    constructor(orderId: string) {
        this.orderId = orderId;
    }


    orderId: string;


    orderStatus: string[] | undefined;


    command: string[] | undefined;


    mstatus: string[] | undefined;


    txnDatetime: SearchRange | undefined;


    amount: SearchRange | undefined;

}
