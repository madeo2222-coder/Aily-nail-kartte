import {ProperOrderInfo} from "./ProperOrderInfo.js";
import {TransactionInfos} from "./TransactionInfos.js";


export class OrderInfo {


    memo1: string | undefined;


    memo2: string | undefined;


    memo3: string | undefined;


    freeKey: string | undefined;


    accountId: string | undefined;


    index: string | undefined;


    serviceTypeCd: string | undefined;


    orderId: string | undefined;


    orderStatus: string | undefined;


    lastSuccessTxnType: string | undefined;


    successDetailTxnType: string | undefined;


    properOrderInfo: ProperOrderInfo | undefined;


    transactionInfos: TransactionInfos | undefined;

}
