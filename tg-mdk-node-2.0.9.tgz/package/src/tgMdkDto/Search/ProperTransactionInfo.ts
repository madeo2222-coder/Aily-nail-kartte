export class ProperTransactionInfo {


    txnKind: string | undefined;


    emTxnType: string | undefined;


    centerProcDatetime: string | undefined;


    cardType: string | undefined;


    cardNo: string | undefined;


    cardBrandCode: string | undefined;


    settlementStatus: string | undefined;


    cvsTxnType: string | undefined;


    peTxnType: string | undefined;


    receiptNo: string | undefined;


    startDatetime: string | undefined;


    cardTransactionType: string | undefined;


    gatewayRequestDate: string | undefined;


    gatewayResponseDate: string | undefined;


    centerRequestDate: string | undefined;


    centerResponseDate: string | undefined;


    centerRequestNumber: string | undefined;


    centerReferenceNumber: string | undefined;


    reqItemCode: string | undefined;


    resItemCode: string | undefined;


    reqReturnReferenceNumber: string | undefined;


    responsedata: string | undefined;


    pending: string | undefined;


    loopback: string | undefined;


    connectedCenterId: string | undefined;


    reqCardNumber: string | undefined;


    reqCardExpire: string | undefined;


    reqAmount: string | undefined;


    reqCardOptionType: string | undefined;


    reqMerchantTransaction: string | undefined;


    reqAuthCode: string | undefined;


    reqAcquirerCode: string | undefined;


    reqCardCenter: string | undefined;


    reqJpoInformation: string | undefined;


    reqSalesDay: string | undefined;


    reqCancelDay: string | undefined;


    reqWithCapture: string | undefined;


    reqWithDirect: string | undefined;


    req3dMessageVersion: string | undefined;


    req3dTransactionId: string | undefined;


    req3dTransactionStatus: string | undefined;


    req3dCavvAlgorithm: string | undefined;


    req3dCavv: string | undefined;


    req3dEci: string | undefined;


    req3dDsTransactionId: string | undefined;


    req3dServerTransactionId: string | undefined;


    reqSecurityCode: string | undefined;


    reqAuthFlag: string | undefined;


    reqBirthday: string | undefined;


    reqTel: string | undefined;


    reqFirstKanaName: string | undefined;


    reqLastKanaName: string | undefined;


    resMerchantTransaction: string | undefined;


    resReturnReferenceNumber: string | undefined;


    resAuthCode: string | undefined;


    resActionCode: string | undefined;


    resCenterErrorCode: string | undefined;


    resAuthTerm: string | undefined;


    reqWithNew: string | undefined;


    amount: string | undefined;


    txnFixed: string | undefined;


    ppTxnType: string | undefined;


    centerTxnId: string | undefined;


    feeAmount: string | undefined;


    exchangeRate: string | undefined;


    netRefundAmount: string | undefined;


    mpiTransactionType: string | undefined;


    reqRedirectionUri: string | undefined;


    corporationId: string | undefined;


    brandId: string | undefined;


    acquirerBinary: string | undefined;


    dsLoginId: string | undefined;


    crresStatus: string | undefined;


    veresStatus: string | undefined;


    paresStatus: string | undefined;


    paresSign: string | undefined;


    paresEci: string | undefined;


    authResponseCode: string | undefined;


    verifyResponseCode: string | undefined;


    res3dMessageVersion: string | undefined;


    res3dTransactionId: string | undefined;


    res3dDsTransactionId: string | undefined;


    res3dServerTransactionId: string | undefined;


    res3dTransactionStatus: string | undefined;


    res3dCavvAlgorithm: string | undefined;


    res3dCavv: string | undefined;


    res3dEci: string | undefined;


    authRequestDatetime: string | undefined;


    authResponseDatetime: string | undefined;


    verifyRequestDatetime: string | undefined;


    verifyResponseDatetime: string | undefined;


    reqCurrencyUnit: string | undefined;


    aqAqfWalletBalance: string | undefined;


    aqAqfPointBalance: string | undefined;


    aqAvailableValue: string | undefined;


    upopTxnType: string | undefined;


    resUpopSettleAmount: string | undefined;


    resUpopSettleDate: string | undefined;


    resUpopSettleCurrency: string | undefined;


    resUpopExchangeDate: string | undefined;


    resUpopExchangeRate: string | undefined;


    resUpopOrderId: string | undefined;


    centerTradeId: string | undefined;


    alipayTxnType: string | undefined;


    settleAmount: string | undefined;


    settleCurrency: string | undefined;


    paymentTime: string | undefined;


    settlementTime: string | undefined;


    payType: string | undefined;


    crResultCode: string | undefined;


    detailCommandType: string | undefined;


    crRequestDatetime: string | undefined;


    crResponseDatetime: string | undefined;


    oricoTxnType: string | undefined;


    orderStateCode: string | undefined;


    approvalNo: string | undefined;


    requestDate: string | undefined;


    loanPrincipal: string | undefined;


    paymentCount: string | undefined;


    jpyAmount: string | undefined;


    resMcpResponseCode: string | undefined;


    rakutenApiErrorCode: string | undefined;


    rakutenOrderErrorCode: string | undefined;


    rakutenRequestDatetime: string | undefined;


    rakutenResponseDatetime: string | undefined;


    recruitErrorCode: string | undefined;


    recruitRequestDatetime: string | undefined;


    recruitResponseDatetime: string | undefined;


    linepayErrorCode: string | undefined;


    linepayRequestDatetime: string | undefined;


    linepayResponseDatetime: string | undefined;


    authCode: string | undefined;


    referenceNumber: string | undefined;


    cardVResultCode: string | undefined;


    masterpassRequestDatetime: string | undefined;


    masterpassResponseDatetime: string | undefined;


    withReconcile: string | undefined;


    depositId: string | undefined;


    registrationMethod: string | undefined;


    depositDate: string | undefined;


    transferName: string | undefined;


    tenpayErrorCode: string | undefined;


    tenpayRequestDatetime: string | undefined;


    tenpayResponseDatetime: string | undefined;


    resCenterProcessNumber: string | undefined;


    resCenterSendDateTime: string | undefined;


    storeId: string | undefined;


    terminalId: string | undefined;


    paypayResultCode: string | undefined;


    settleBizCode: string | undefined;


    receiptNumber: string | undefined;


    itemName: string | undefined;


    paypayRequestDatetime: string | undefined;


    paypayResponseDatetime: string | undefined;


    paypayOnlineTxnId: string | undefined;


    paypayErrorCode: string | undefined;


    gatewayTransId: string | undefined;


    alipayxResultCode: string | undefined;


    alipayxRequestDatetime: string | undefined;


    alipayxResponseDatetime: string | undefined;


    cvspayResultCd: string | undefined;


    cvspayRequestDatetime: string | undefined;


    cvspayResponseDatetime: string | undefined;


    cvspayCancelOrderId: string | undefined;


    authorResult: string | undefined;


    centerTransactionId: string | undefined;


    centerResultCode: string | undefined;


    centerStateCode: string | undefined;


    centerReasonCode: string | undefined;


    merpayErrorCode: string | undefined;


    operatorId: string | undefined;


    slipCode: string | undefined;


    merpayResourceId: string | undefined;


    merpayProcessingId: string | undefined;


    merpayRequestDatetime: string | undefined;


    merpayResponseDatetime: string | undefined;


    inquiryCode: string | undefined;


    useCredit: string | undefined;


    useCoupon: string | undefined;


    usePoint: string | undefined;


    eposRequestDatetime: string | undefined;


    eposResponseDatetime: string | undefined;


    reqPaymentType: string | undefined;


    reqResponseCode: string | undefined;


    fdResult: string | undefined;


    frequencyUnit: string | undefined;


    frequencyValue: string | undefined;


    rakutenApiErrorType: string | undefined;


    accountBalance: string | undefined;


    bankpayErrorCode: string | undefined;


    bankpayRequestDatetime: string | undefined;


    bankpayResponseDatetime: string | undefined;


}
